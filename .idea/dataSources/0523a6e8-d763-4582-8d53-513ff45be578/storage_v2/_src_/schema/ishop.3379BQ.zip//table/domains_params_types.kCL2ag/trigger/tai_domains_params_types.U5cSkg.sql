create trigger tai_domains_params_types
  after INSERT
  on domains_params_types
  for each row
  insert into `_log_update_signal` (`entity_type`,`entity_id`,`trigger_name`) values ('domains_params_types',NEW.type_id,'tai_domains_params_types') on duplicate key update `change_time`=now(),`trigger_name`=values(`trigger_name`);

