create trigger tai_provider
  after INSERT
  on provider
  for each row
  insert into `_log_update_signal` (`entity_type`,`entity_id`,`trigger_name`) values ('provider',NEW.provider_id,'tai_provider') on duplicate key update `change_time`=now(),`trigger_name`=values(`trigger_name`);

