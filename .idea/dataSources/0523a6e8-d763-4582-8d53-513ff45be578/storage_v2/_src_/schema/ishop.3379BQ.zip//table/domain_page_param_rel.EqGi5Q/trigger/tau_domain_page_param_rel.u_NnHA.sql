create trigger tau_domain_page_param_rel
  after UPDATE
  on domain_page_param_rel
  for each row
  insert into `_log_update_signal` (`entity_type`,`entity_id`,`trigger_name`) values('domain_page_param_rel',NEW.page_id,'tau_domain_page_param_rel') on duplicate key update `change_time`=now(),`trigger_name`=values(`trigger_name`);

