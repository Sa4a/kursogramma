create trigger tad_product_balance
  after DELETE
  on product_balance
  for each row
  insert into `_log_update_signal` (`entity_type`,`entity_id`,`trigger_name`) values ('product_balance',OLD.product_id,'tad_product_balance') on duplicate key update `change_time`=now(),`trigger_name`=values(`trigger_name`);

