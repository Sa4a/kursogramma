create trigger tad_partners
  after DELETE
  on partners
  for each row
  insert into `_log_update_signal` (`entity_type`,`entity_id`,`trigger_name`) values ('partners',OLD.partner_id,'tad_partners') on duplicate key update `change_time`=now(),`trigger_name`=values(`trigger_name`);

