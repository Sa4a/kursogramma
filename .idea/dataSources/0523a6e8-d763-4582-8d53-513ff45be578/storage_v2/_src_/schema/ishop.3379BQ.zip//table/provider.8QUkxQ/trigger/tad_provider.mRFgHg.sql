create trigger tad_provider
  after DELETE
  on provider
  for each row
  insert into `_log_update_signal` (`entity_type`,`entity_id`,`trigger_name`) values ('provider',OLD.provider_id,'tad_provider') on duplicate key update `change_time`=now(),`trigger_name`=values(`trigger_name`);

