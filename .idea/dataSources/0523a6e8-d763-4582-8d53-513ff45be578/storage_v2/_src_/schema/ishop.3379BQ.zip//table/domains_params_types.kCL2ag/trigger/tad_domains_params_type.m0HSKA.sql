create trigger tad_domains_params_type
  after DELETE
  on domains_params_types
  for each row
  insert into `_log_update_signal` (`entity_type`,`entity_id`,`trigger_name`) values ('domains_params_type',OLD.type_id,'tad_domains_params_type') on duplicate key update `change_time`=now(),`trigger_name`=values(`trigger_name`);

