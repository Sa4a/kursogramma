create trigger tad_sale_types
  after DELETE
  on sale_types
  for each row
  insert into `_log_update_signal` (`entity_type`,`entity_id`,`trigger_name`) values ('sale_types',OLD.sale_type_id,'tad_sale_types') on duplicate key update `change_time`=now(),`trigger_name`=values(`trigger_name`);

