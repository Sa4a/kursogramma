create trigger tad_domains
  after DELETE
  on domains
  for each row
  insert into `_log_update_signal` (`entity_type`,`entity_id`,`trigger_name`) values ('domains',OLD.domain_id,'tad_domains') on duplicate key update `change_time`=now(),`trigger_name`=values(`trigger_name`);

