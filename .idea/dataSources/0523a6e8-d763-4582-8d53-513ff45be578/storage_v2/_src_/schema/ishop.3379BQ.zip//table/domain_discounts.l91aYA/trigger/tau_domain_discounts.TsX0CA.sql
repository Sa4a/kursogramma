create trigger tau_domain_discounts
  after UPDATE
  on domain_discounts
  for each row
  insert into `_log_update_signal` (`entity_type`,`entity_id`,`trigger_name`) values ('domain_discounts',NEW.discount_id,'tau_domain_discounts') on duplicate key update `change_time`=now(),`trigger_name`=values(`trigger_name`);

