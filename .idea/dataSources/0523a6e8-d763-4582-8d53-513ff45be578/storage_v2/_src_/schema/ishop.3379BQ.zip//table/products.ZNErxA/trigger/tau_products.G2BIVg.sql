create trigger tau_products
  after UPDATE
  on products
  for each row
  insert into `_log_update_signal` (`entity_type`,`entity_id`,`trigger_name`) values ('products',NEW.product_id,'tau_products') on duplicate key update `change_time`=now(),`trigger_name`=values(`trigger_name`);

