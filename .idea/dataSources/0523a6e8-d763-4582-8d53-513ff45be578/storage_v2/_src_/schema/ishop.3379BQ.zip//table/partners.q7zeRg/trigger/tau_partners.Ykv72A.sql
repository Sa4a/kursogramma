create trigger tau_partners
  after UPDATE
  on partners
  for each row
  IF NEW.partner_discount <> OLD.partner_discount THEN insert into `_log_update_signal` (`entity_type`,`entity_id`,`trigger_name`) values ('partners',NEW.partner_id,'tau_partners') on duplicate key update `change_time`=now(),`trigger_name`=values(`trigger_name`); END IF;

