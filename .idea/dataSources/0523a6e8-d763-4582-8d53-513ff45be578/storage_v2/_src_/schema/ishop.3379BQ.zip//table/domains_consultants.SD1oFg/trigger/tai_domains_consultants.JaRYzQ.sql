create trigger tai_domains_consultants
  after INSERT
  on domains_consultants
  for each row
  insert into `_log_update_signal` (`entity_type`,`entity_id`,`trigger_name`) values ('domains_consultants',NEW.domain_consultant_id,'tai_domains_consultants') on duplicate key update `change_time`=now(),`trigger_name`=values(`trigger_name`);

