create trigger tau_domains
  after UPDATE
  on domains
  for each row
  insert into `_log_update_signal` (`entity_type`,`entity_id`,`trigger_name`) values ('domain',NEW.domain_id,'tau_domains') on duplicate key update `change_time`=now(),`trigger_name`=values(`trigger_name`);

