create trigger tad_domains_consultants
  after DELETE
  on domains_consultants
  for each row
  insert into `_log_update_signal` (`entity_type`,`entity_id`,`trigger_name`) values ('domains_consultants',OLD.domain_consultant_id,'tad_domains_consultants') on duplicate key update `change_time`=now(),`trigger_name`=values(`trigger_name`);

