create trigger tad_domain_page_product
  after DELETE
  on domain_page_product
  for each row
  insert into `_log_update_signal` (`entity_type`,`entity_id`,`trigger_name`) values ('domain_page_product',OLD.page_id,'tad_domain_page_product') on duplicate key update `change_time`=now(),`trigger_name`=values(`trigger_name`);

