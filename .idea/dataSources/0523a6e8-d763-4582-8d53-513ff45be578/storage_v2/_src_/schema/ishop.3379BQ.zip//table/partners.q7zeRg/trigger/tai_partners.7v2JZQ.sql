create trigger tai_partners
  after INSERT
  on partners
  for each row
  insert into `_log_update_signal` (`entity_type`,`entity_id`,`trigger_name`) values ('partners',NEW.partner_id,'tai_partners') on duplicate key update `change_time`=now(),`trigger_name`=values(`trigger_name`);

