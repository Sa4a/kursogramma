create trigger tai_product_balance
  after INSERT
  on product_balance
  for each row
  insert into `_log_update_signal` (`entity_type`,`entity_id`,`trigger_name`) values ('product_balance',NEW.product_id,'tai_product_balance') on duplicate key update `change_time`=now(),`trigger_name`=values(`trigger_name`);

