create trigger tai_domain_page_param
  after INSERT
  on domain_page_param
  for each row
  insert into `_log_update_signal` (`entity_type`,`entity_id`,`trigger_name`) values ('domain_page_param',NEW.parameter_id,'tai_domain_page_param') on duplicate key update `change_time`=now(),`trigger_name`=values(`trigger_name`);

