create trigger tad_domain_page_param_type
  after DELETE
  on domain_page_param_type
  for each row
  insert into `_log_update_signal` (`entity_type`,`entity_id`,`trigger_name`) values ('domain_page_param_type',OLD.type_id,'tad_domain_page_param_type') on duplicate key update `change_time`=now(),`trigger_name`=values(`trigger_name`);

